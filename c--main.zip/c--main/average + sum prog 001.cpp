# include <iostream>
using namespace std;
int main()

{
int a , b, sum;

 float average;

 cout<<("enter the first number:");
 cin>>a;

 cout<<("enter second number");
 cin>>b;

 sum = a + b;

 average = sum/2;

 cout<<"the sum of the two numbers is" <<sum<<end1;
 cout<<"the average of the two numbers is" <<average<<end1;

return 0;
}
