#include <iostream>
#include<math.h>
using namespace std;

int main()
{
float sq,n;
cout<<"enter any number:";
cin>>n;
sq = sqrt (n);
cout<< "square root of "<<n<<" is "<<sq;
return 0;
}
